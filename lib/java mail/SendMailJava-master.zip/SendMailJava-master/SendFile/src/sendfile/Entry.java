/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sendfile;

/**
 *
 * @author Administrator
 */
public class Entry {
    public static void main(String[] args) {
        Action action = new Action();
        action.getGui().setVisible(true);
    }
}
